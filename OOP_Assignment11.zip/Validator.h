#pragma once

#include "Error.h"
#include "Turret.h"

class Validator
{
public:
	void validate(Turret turret);
};

